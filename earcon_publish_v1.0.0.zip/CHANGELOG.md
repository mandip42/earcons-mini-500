# Changelog

## v1.0.0 — Initial public release
- Added generator for synthetic earcons with parameterized grid.
- Added feature computation and tiny baselines (classification, f0 regression).
- Added arXiv data note skeleton and repository scaffolding.
