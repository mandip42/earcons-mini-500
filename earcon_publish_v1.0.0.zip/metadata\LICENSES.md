# Audio License Statement

All **generated audio files** in this repository are released under **CC0 1.0 Universal (CC0‑1.0)** public domain dedication.

If any third‑party CC‑BY/CC0 assets are added in future versions, list full attributions here in a table:

| file | author | source URL | license | changes |
|------|--------|------------|---------|---------|
